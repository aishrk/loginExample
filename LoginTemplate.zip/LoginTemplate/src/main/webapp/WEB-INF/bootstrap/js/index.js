/*
  Inspired by https://dribbble.com/shots/1613291-Everdwell-Login.

  2014 by Kaushalya Mandaliya
  http://seebeetee.com / @kmandalwala
*/